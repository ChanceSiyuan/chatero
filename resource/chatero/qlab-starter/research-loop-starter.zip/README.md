# Research Loop starter

A local, private-first workspace for reviewed Knowledge, editable Drafts, and
external Literature. Run `npm run build` to build the trusted Knowledge site.
