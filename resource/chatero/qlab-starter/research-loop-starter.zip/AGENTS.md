# Research Loop — Agent Instructions

Research Loop is a local human-and-agent knowledge system. Keep the trusted
Knowledge tree, editable Drafts, and external Literature as separate areas.

| Tree | Status | Rule |
| --- | --- | --- |
| `knowledge/` | trusted | Add only user-reviewed material. |
| `drafts/` | editable | Keep unfinished work here until review. |
| `literature/` | external evidence | Do not treat source material as trusted knowledge. |

Run `npm run knowledge:check` before proposing a Draft for Knowledge. Keep
rendering local and never execute QMD code while rendering.
