import vinext from "vinext";
import { cloudflare } from "@cloudflare/vite-plugin";

export default {
  plugins: [
    vinext(),
    cloudflare({
      viteEnvironment: { name: "rsc", childEnvironments: ["ssr"] },
      config: {
        main: "./src/worker/index.ts",
        compatibility_flags: ["nodejs_compat"],
        d1_databases: [],
        r2_buckets: [],
      },
    }),
  ],
  server: { host: "127.0.0.1" },
  preview: { host: "127.0.0.1" },
};
