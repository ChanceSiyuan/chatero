# Research Loop

Follow the repository trust boundary and workflow in `AGENTS.md`.
