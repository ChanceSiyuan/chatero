const workflows = [
  ["Repository", "Initialize or inspect the local Research Loop workspace.", "/"],
  ["Knowledge", "Read trusted notes built from validated QMD files.", "/knowledge/"],
  ["Drafts", "Preview and check editable QMD research drafts.", "/drafts"],
  ["Literature", "Index evidence and synchronize approved Zotero metadata.", "/literature"],
] as const;

export default function Home() {
  return <main><p>Research Loop</p><h1>Local research workspace</h1><p>Use the validated workflows below. Your notes and citations remain on this computer.</p><section className="grid">{workflows.map(([name, description, href]) => <a className="card" href={href} key={name}><h2>{name}</h2><p>{description}</p></a>)}</section></main>;
}
