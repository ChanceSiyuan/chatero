export default function LiteraturePage() { return <main><h1>Literature</h1><p>Run <code>npm run literature:index</code> to derive local method indexes from ref.bib.</p></main>; }
