export function healthResponse(repositoryIdentity = process.env.QLAB_REPOSITORY_ID ?? null) {
  return { ok: true, repositoryIdentity };
}
