import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json({ ok: true, repositoryIdentity: process.env.QLAB_REPOSITORY_ID ?? null });
}
