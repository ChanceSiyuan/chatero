export default function DraftsPage() { return <main><h1>Drafts</h1><p>Run <code>npm run draft:check -- --file drafts/&lt;note&gt;.qmd</code> before review.</p></main>; }
