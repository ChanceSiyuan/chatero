import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const repository = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const output = join(repository, "dist");
await mkdir(output, { recursive: true });
await writeFile(join(output, "index.html"), [
  "<!doctype html>",
  "<html><head><meta charset=\"utf-8\"><title>Research Loop</title></head>",
  "<body><main><h1>Research Loop</h1><p><a href=\"/knowledge/\">Open Knowledge</a></p></main></body></html>",
].join(""));
