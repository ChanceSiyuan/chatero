import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const repository = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const port = Number.parseInt(process.env.PORT ?? "4180", 10);
const safePort = Number.isInteger(port) && port > 0 && port < 65536 ? port : 4180;
const contentTypes = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8" };

createServer(async (request, response) => {
  const pathname = new URL(request.url ?? "/", "http://127.0.0.1").pathname;
  if (pathname === "/api/qlab/health") {
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ ok: true, repositoryIdentity: process.env.QLAB_REPOSITORY_ID ?? null }));
    return;
  }
  const relative = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const safe = normalize(relative).replace(/^([.][.][/\\])+/, "");
  const target = join(repository, safe.startsWith("knowledge/") ? "public" : "dist", safe.startsWith("knowledge/") ? safe : safe);
  try {
    response.writeHead(200, { "content-type": contentTypes[extname(target)] ?? "application/octet-stream" });
    response.end(await readFile(target));
  } catch {
    response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    response.end("Not found");
  }
}).listen(safePort, "127.0.0.1", () => {
  console.log("Research Loop is available at http://127.0.0.1:" + safePort + "/");
});
