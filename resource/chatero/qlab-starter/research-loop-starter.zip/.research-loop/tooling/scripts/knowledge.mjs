import { readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const repository = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const indexPath = join(repository, "knowledge", "index.qmd");

async function checkKnowledge() {
  const index = await readFile(indexPath, "utf8");
  if (!/^description:\s*["'][^"']+["']$/m.test(index)) {
    throw new Error("knowledge/index.qmd requires a non-empty description");
  }
  if (!/^## Reading map$/m.test(index)) {
    throw new Error("knowledge/index.qmd requires a ## Reading map section");
  }
}

const command = process.argv[2];
if (command !== "check" && command !== "build") {
  console.error("Usage: knowledge.mjs <check|build>");
  process.exitCode = 2;
} else {
  try {
    await checkKnowledge();
    if (command === "build") {
      const result = spawnSync("quarto", ["render", "knowledge", "--no-execute"], {
        cwd: repository,
        stdio: "inherit",
      });
      if (result.status !== 0) process.exitCode = result.status ?? 1;
    } else {
      console.log("knowledge: the trusted tree is valid");
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}
