const command = process.argv.slice(2).join(" ");
if (!command || command === "--help") {
  console.log("Research Loop starter: use npm run knowledge:check, npm run build, or npm run start.");
} else {
  console.error("Unsupported starter command: " + command);
  process.exitCode = 2;
}
